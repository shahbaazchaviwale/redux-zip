import React, { Component } from 'react'
import { connect } from 'react-redux';
import TodoItem from './todo-item';
import TodoForm from './todo-form';
import store from '../../store/store'
class TodosList extends Component {
  render() {
    console.log("store >>>", store.getState().todos);
    return (
      <div className="ui grid">
        <div className="six wide column">
          <h3>List of Todos</h3>
          <TodoForm />
          <div className="ui selection aligned list">
            {
              this.props.todos.map(todo => <TodoItem key={todo.id} todo={todo} />)
            }
          </div>
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    todos: state.todos
  }
} 

export default connect(mapStateToProps)(TodosList);